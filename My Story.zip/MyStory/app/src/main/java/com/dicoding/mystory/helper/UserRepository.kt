package com.dicoding.mystory.helper

import androidx.lifecycle.LiveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.dicoding.mystory.data.pref.UserModel
import com.dicoding.mystory.data.pref.UserPreference
import com.dicoding.mystory.data.response.DetailStoryResponse
import com.dicoding.mystory.data.response.FileUploadResponse
import com.dicoding.mystory.data.response.ListStoryItem
import com.dicoding.mystory.data.response.ListStoryResponse
import com.dicoding.mystory.data.response.LoginResponse
import com.dicoding.mystory.data.response.RegisterResponse
import com.dicoding.mystory.data.retrofit.ApiService
import com.dicoding.mystory.view.adapter.ListStoryPagingSource
import kotlinx.coroutines.flow.Flow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class UserRepository (
    private val userPreference: UserPreference,
    private val apiService: ApiService
){
    suspend fun saveSession(user: UserModel) {
        userPreference.saveSession(user)
    }

    fun getSession(): Flow<UserModel> {
        return userPreference.getSession()
    }

    suspend fun logout() {
        userPreference.logout()
    }

    suspend fun register(name: String, email: String, password: String): RegisterResponse {
        return apiService.register(name, email, password)
    }

    suspend fun login(email: String,password: String): LoginResponse {
        val response = apiService.login(email, password)
        if (response.error == false) {
            val userModel = UserModel(email, response.loginResult?.token ?: "")
            userPreference.saveSession(userModel)
        }
        return response
    }

    fun getStory(): LiveData<PagingData<ListStoryItem>> {
        return Pager(
            config = PagingConfig(
                pageSize = 5
            ),
            pagingSourceFactory = {
                ListStoryPagingSource(apiService)
            }
        ).liveData
    }

    suspend fun getStoryWithLocation(): ListStoryResponse {
        return apiService.getStoryWithLocation()
    }

    suspend fun getStoryId(id: String): DetailStoryResponse {
        return apiService.getStoryId(id)
    }

    suspend fun uploadImage(file: File, description: String): FileUploadResponse {
        val requestFile = file.asRequestBody("image/jpeg".toMediaType())
        val multipartBody = MultipartBody.Part.createFormData("photo", file.name, requestFile)
        val descriptionBody = description.toRequestBody("text/plain".toMediaType())
        return apiService.uploadImage(multipartBody, descriptionBody)
    }

    companion object {
        fun getInstance(
            userPreference: UserPreference,
            apiService: ApiService
        ) = UserRepository(userPreference, apiService)
    }
}