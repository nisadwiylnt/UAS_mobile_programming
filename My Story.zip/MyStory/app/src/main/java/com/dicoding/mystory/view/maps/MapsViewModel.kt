package com.dicoding.mystory.view.maps

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.mystory.data.response.ErrorResponse
import com.dicoding.mystory.data.response.ListStoryResponse
import com.dicoding.mystory.helper.UserRepository
import com.google.gson.Gson
import kotlinx.coroutines.launch
import retrofit2.HttpException

class MapsViewModel (private val userRepository: UserRepository) : ViewModel() {
    private val _story = MutableLiveData<ListStoryResponse>()
    val story: LiveData<ListStoryResponse> = _story

    fun getStoryWithLocation() {
        viewModelScope.launch {
            try {
                val response = userRepository.getStoryWithLocation()
                _story.value = response
            } catch (e: HttpException) {
                val errorBody = e.response()?.errorBody()?.string()
                if (errorBody != null && errorBody.startsWith("<html>")) {
                    _story.value = ListStoryResponse(error = true, message = "Received HTML response instead of JSON")
                } else {
                    val errorResponse = Gson().fromJson(errorBody, ErrorResponse::class.java)
                    val errorMessage = errorResponse.message
                    _story.value = ListStoryResponse(error = true, message = errorMessage)
                }
            } catch (e: Exception) {
                _story.value = ListStoryResponse(error = true, message = "An error occurred: ${e.message}")
            }
        }
    }
}